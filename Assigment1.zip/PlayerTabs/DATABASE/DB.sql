USE [master]
GO

/****** Object:  Database [PlayerTab]    Script Date: 2019-10-18 10:21:11 PM ******/
DROP DATABASE [PlayerTab]
GO

