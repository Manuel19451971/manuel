﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PlayerTabs.Models
{
    public partial class Car
    {
        public int CarId { get; set; }
        public decimal? Cost { get; set; }
        [StringLength(10)]
        public string Brand { get; set; }
        public int? Year { get; set; }
        public int? PlayerId { get; set; }

        [ForeignKey("PlayerId")]
        [InverseProperty("Car")]
        public Player Player { get; set; }
    }
}
