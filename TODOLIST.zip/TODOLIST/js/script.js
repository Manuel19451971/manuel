// variables
let input = document.querySelector("#input");
let add = document.querySelector("#add");
let list = document.querySelector("#list");
let audio = document.querySelectorAll("audio")[0];
let todoList = [];

// this is the event listener
add.addEventListener("click", function () {
	// check if the text field is not empty

		  if (input.value.trim().length > 0) {
		// this will push text field value into the todoList array
		todoList.push({
			"text": input.value.trim(),
			"checked": false
		});
		// play the sound
		audio.src = 'sounds/pling.mp3';
		audio.play();
		// refresh to do list
		updateList();

		// clear the text field value
		input.value = "";
	}
})

function updateList() {
	// clear the div element
	list.innerHTML = "";
	// loop into todoList array
	for (let i = 0; i < todoList.length; i++) {
		// create a div element
	let div = document.createElement("div");
	div.classList.add("todoItem");
	div.id = i;
		// if element is checked then add checked class to element.
	let checked = "";
	  	if (todoList[i].checked) {
			checked = "checked";
		}




     //insert the html
		div.innerHTML = '<div class="checkbox"><input type="checkbox" '+checked+'></div><div class="items '+checked+'">'+todoList[i].text+'</div><div class="remove">X</div>';

		list.appendChild(div);
		// checkbox event listener
		let checkboxes = document.querySelectorAll("input[type=checkbox]");
		checkboxes[checkboxes.length - 1].addEventListener("change", function () {
		changeCheckbox(this);
		});

		// remove button event listener
		let remove = document.querySelectorAll(".remove");
		remove[remove.length - 1].addEventListener("click", function () {
		let parent = this.parentElement;
			let textElement = parent.children[1];
			 textElement.classList.add("delete");
			setTimeout(function () {
				// remove item from todoList array
				todoList.splice(parent.id, 1);
				// refresh the list
			  	updateList();
				// play sound
			  	audio.src = 'sounds/whip.mp3';
				audio.play();
			}, 1000);
		});

	}
}

function changeCheckbox(elem) {
	let parent = elem.parentElement.parentElement;
	let textElement = parent.children[1];
	if (elem.checked) {
	textElement.classList.add("checked");
	todoList[parent.id].checked = true;
	  	let temp = todoList[parent.id];
		todoList.splice(parent.id, 1);
		todoList.push(temp);
		updateList();
	} else {
		textElement.classList.remove("checked");
		todoList[elem.id].checked = false;
	}
}
