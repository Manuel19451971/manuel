﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PlayerTabs.Models
{
    public partial class Player
    {
        public Player()
        {
            Car = new HashSet<Car>();
        }

        public int PlayerId { get; set; }
        [Required]
        [StringLength(50)]
        public string PlayerName { get; set; }
        [Required]
        [StringLength(50)]
        public string Country { get; set; }
        [Required]
        [StringLength(50)]
        public string Team { get; set; }

        [InverseProperty("Player")]
        public ICollection<Car> Car { get; set; }
    }
}
